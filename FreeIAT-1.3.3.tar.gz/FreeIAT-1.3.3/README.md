# FreeIAT
Public repository for the FreeIAT program

Right-click and download the "FreeIAT installer.exe" program to get started. 

See https://meade.wordpress.ncsu.edu/freeiat-home/ for full documentation. 

