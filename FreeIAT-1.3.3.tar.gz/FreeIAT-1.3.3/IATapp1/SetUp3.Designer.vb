﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SetUp3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SetUp3))
        Me.btnCancel = New System.Windows.Forms.Button
        Me.btnNext = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.tbStim2 = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.tbStim1 = New System.Windows.Forms.TextBox
        Me.tbStim2Lab = New System.Windows.Forms.TextBox
        Me.tbStim1Lab = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'btnCancel
        '
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.Location = New System.Drawing.Point(320, 579)
        Me.btnCancel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(88, 36)
        Me.btnCancel.TabIndex = 20
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnNext
        '
        Me.btnNext.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNext.Location = New System.Drawing.Point(427, 579)
        Me.btnNext.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(88, 36)
        Me.btnNext.TabIndex = 19
        Me.btnNext.Text = "Next ->"
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(453, 87)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(301, 114)
        Me.Label4.TabIndex = 18
        Me.Label4.Text = "Enter each word in Condition 2 in the box below, hitting return after each."
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'tbStim2
        '
        Me.tbStim2.AcceptsReturn = True
        Me.tbStim2.Location = New System.Drawing.Point(455, 203)
        Me.tbStim2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.tbStim2.Multiline = True
        Me.tbStim2.Name = "tbStim2"
        Me.tbStim2.Size = New System.Drawing.Size(297, 357)
        Me.tbStim2.TabIndex = 17
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(45, 87)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(301, 114)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "Enter each word in Condition 1 in the box below, hitting return after each."
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'tbStim1
        '
        Me.tbStim1.AcceptsReturn = True
        Me.tbStim1.Location = New System.Drawing.Point(49, 203)
        Me.tbStim1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.tbStim1.Multiline = True
        Me.tbStim1.Name = "tbStim1"
        Me.tbStim1.Size = New System.Drawing.Size(297, 357)
        Me.tbStim1.TabIndex = 15
        '
        'tbStim2Lab
        '
        Me.tbStim2Lab.Location = New System.Drawing.Point(453, 50)
        Me.tbStim2Lab.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.tbStim2Lab.Name = "tbStim2Lab"
        Me.tbStim2Lab.Size = New System.Drawing.Size(297, 22)
        Me.tbStim2Lab.TabIndex = 14
        '
        'tbStim1Lab
        '
        Me.tbStim1Lab.Location = New System.Drawing.Point(44, 50)
        Me.tbStim1Lab.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.tbStim1Lab.Name = "tbStim1Lab"
        Me.tbStim1Lab.Size = New System.Drawing.Size(301, 22)
        Me.tbStim1Lab.TabIndex = 13
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(451, 28)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(144, 20)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "Condition 2 Label:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(40, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(144, 20)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Condition 1 Label:"
        '
        'SetUp3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(792, 626)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.tbStim2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.tbStim1)
        Me.Controls.Add(Me.tbStim2Lab)
        Me.Controls.Add(Me.tbStim1Lab)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "SetUp3"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Configure Page 3 of 4"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents tbStim2 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents tbStim1 As System.Windows.Forms.TextBox
    Friend WithEvents tbStim2Lab As System.Windows.Forms.TextBox
    Friend WithEvents tbStim1Lab As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
